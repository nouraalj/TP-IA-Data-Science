# -*- coding: utf-8 -*-

"""
Package: iads
File: __init__.py
Année: LU3IN026 - semestre 2 - 2022-2023, Sorbonne Université
"""

